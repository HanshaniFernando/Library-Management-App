package com.example.libraryapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ManageMemberActivity extends AppCompatActivity {
    private EditText editTextCardNo, editTextName, editTextAddress, editTextPhone, editTextUnpaidDues;
    private Button buttonAddMember, buttonViewMembers, buttonUpdateMember, buttonDeleteMember;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_members);

        editTextCardNo = findViewById(R.id.editTextCardNo);
        editTextName = findViewById(R.id.editTextName);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextUnpaidDues = findViewById(R.id.editTextUnpaidDues);
        buttonAddMember = findViewById(R.id.buttonAddMember);
        buttonViewMembers = findViewById(R.id.buttonViewMembers);
        buttonUpdateMember = findViewById(R.id.buttonUpdateMember);
        buttonDeleteMember = findViewById(R.id.buttonDeleteMember);

        buttonAddMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMember();
            }
        });

        // Implement onClick listeners for other buttons (view, update, delete) as needed
    }

    private void addMember() {
        String cardNo = editTextCardNo.getText().toString().trim();
        String name = editTextName.getText().toString().trim();
        String address = editTextAddress.getText().toString().trim();
        String phone = editTextPhone.getText().toString().trim();
        String unpaidDues = editTextUnpaidDues.getText().toString().trim();

        // Validate input fields
        if (cardNo.isEmpty() || name.isEmpty() || address.isEmpty() || phone.isEmpty() || unpaidDues.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Perform database operation to add member
        // Use DatabaseHelper class to insert member details into database

        // Clear input fields
        editTextCardNo.setText("");
        editTextName.setText("");
        editTextAddress.setText("");
        editTextPhone.setText("");
        editTextUnpaidDues.setText("");

        Toast.makeText(this, "Member added successfully", Toast.LENGTH_SHORT).show();
    }

    // Implement methods for view, update, and delete operations as needed
}
