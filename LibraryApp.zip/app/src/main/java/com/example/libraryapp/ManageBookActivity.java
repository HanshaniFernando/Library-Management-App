package com.example.libraryapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ManageBookActivity extends AppCompatActivity {
    private EditText editTextId, editTextTitle, editTextPublisher;
    private Button buttonAddBook, buttonViewBooks, buttonUpdateBook, buttonDeleteBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_books);

        editTextId = findViewById(R.id.editTextId);
        editTextTitle = findViewById(R.id.editTextTitle);
        editTextPublisher = findViewById(R.id.editTextPublisher);
        buttonAddBook = findViewById(R.id.buttonAddBook);
        buttonViewBooks = findViewById(R.id.buttonViewBooks);
        buttonUpdateBook = findViewById(R.id.buttonUpdateBook);
        buttonDeleteBook = findViewById(R.id.buttonDeleteBook);

        buttonAddBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {addBook();
            }
        });

        // Implement onClick listeners for other buttons (view, update, delete) as needed
    }

    private void addBook() {
        String id = editTextId.getText().toString().trim();
        String title = editTextTitle.getText().toString().trim();
        String publisher = editTextPublisher.getText().toString().trim();

        // Validate input fields
        if (id.isEmpty() || title.isEmpty() || publisher.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Perform database operation to add book
        // Use DatabaseHelper class to insert book details into database

        // Clear input fields
        editTextId.setText("");
        editTextTitle.setText("");
        editTextPublisher.setText("");

        Toast.makeText(this, "Book added successfully", Toast.LENGTH_SHORT).show();
    }

    // Implement methods for view, update, and delete operations as needed
}

