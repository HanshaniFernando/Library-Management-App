import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Define database name, version, and table names
    private static final String DATABASE_NAME = "library.db";
    private static final int DATABASE_VERSION = 1;

    // Define table names
    private static final String TABLE_BOOKS = "books";
    private static final String COL_ID = "id";
    private static final String COL_TITLE = "title";
    private static final String COL_AUTHOR = "author";
    private static final String COL_PUBLISHER = "publisher";


    private static final String TABLE_MEMBERS = "members";
    private static final String COL_NAME = "name";
    private static final String COL_EMAIL = "email";
    private static final String COL_ADDRESS = "address";
    private static final String COL_PHONE = "phone";
    private static final String COL_UNPAID_DUES = "unpaid_dues";



    private static final String TABLE_LENDINGS = "lendings";

    private static final String COL_BOOK_ID = "book_id";
    private static final String COL_MEMBER_ID = "member_id";
    private static final String COL_LENDING_DATE = "lending_date";
    private static final String COL_RETURN_DATE = "return_date";

    private static final String TABLE_BRANCHES = "branches";
    private static final String COL_BRANCH_ID = "branch_id";
    private static final String COL_BRANCH_NAME = "branch_name";
    private static final String COL_BRANCH_ADDRESS = "branch_address";
    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create books table
        String createBooksTable = "CREATE TABLE " + TABLE_BOOKS + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_TITLE + " TEXT,"
                + COL_AUTHOR + " TEXT,"
                + COL_PUBLISHER + " TEXT"
                + ")";
        db.execSQL(createBooksTable);

        // Create members table
        String createMembersTable = "CREATE TABLE " + TABLE_MEMBERS + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_NAME + " TEXT,"
                + COL_EMAIL + " TEXT,"
                + COL_ADDRESS + " TEXT,"
                + COL_PHONE + " TEXT,"
                + COL_UNPAID_DUES + " INTEGER"
                + ")";
        db.execSQL(createMembersTable);


        String createLendingsTable = "CREATE TABLE " + TABLE_LENDINGS + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_BOOK_ID + " INTEGER,"
                + COL_MEMBER_ID + " INTEGER,"
                + COL_LENDING_DATE + " TEXT,"
                + COL_RETURN_DATE + " TEXT"
                + ")";
        db.execSQL(createLendingsTable);

        String createBranchesTable = "CREATE TABLE " + TABLE_BRANCHES + " ("
                + COL_BRANCH_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_BRANCH_NAME + " TEXT,"
                + COL_BRANCH_ADDRESS + " TEXT"
                + ")";
        db.execSQL(createBranchesTable);

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Upgrade database (if needed)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MEMBERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LENDINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BRANCHES);
        onCreate(db);
    }
    // CRUD Operations for Books Table

    // Insert a new book
    public long insertBook(String title, String author, String publisher) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, title);
        values.put(COL_AUTHOR, author);
        values.put(COL_PUBLISHER, publisher);
        return db.insert(TABLE_BOOKS, null, values);
    }

    // Retrieve all books
    public Cursor getAllBooks() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_BOOKS, null, null, null, null, null, null);
    }

    // Update a book
    public int updateBook(int id, String title, String author, String publisher) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, title);
        values.put(COL_AUTHOR, author);
        values.put(COL_PUBLISHER, publisher);
        return db.update(TABLE_BOOKS, values, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Delete a book
    public int deleteBook(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_BOOKS, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    // CRUD Operations for Members Table

    // Insert a new member
    public long insertMember(String name, String email, String address, String phone, int unpaidDues) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_EMAIL, email);
        values.put(COL_ADDRESS, address);
        values.put(COL_PHONE, phone);
        values.put(COL_UNPAID_DUES, unpaidDues);
        return db.insert(TABLE_MEMBERS, null, values);
    }

    // Retrieve all members
    public Cursor getAllMembers() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_MEMBERS, null, null, null, null, null, null);
    }

    // Update a member
    public int updateMember(int id, String name, String email, String address, String phone, int unpaidDues) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_EMAIL, email);
        values.put(COL_ADDRESS, address);
        values.put(COL_PHONE, phone);
        values.put(COL_UNPAID_DUES, unpaidDues);
        return db.update(TABLE_MEMBERS, values, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Delete a member
    public int deleteMember(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_MEMBERS, COL_ID + "=?", new String[]{String.valueOf(id)});
    }


    // CRUD Operations for Lendings Table

    // Insert a new lending record
    public long insertLending(int bookId, int memberId, String lendingDate, String returnDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_BOOK_ID, bookId);
        values.put(COL_MEMBER_ID, memberId);
        values.put(COL_LENDING_DATE, lendingDate);
        values.put(COL_RETURN_DATE, returnDate);
        return db.insert(TABLE_LENDINGS, null, values);
    }

    // Retrieve all lending records
    public Cursor getAllLendings() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_LENDINGS, null, null, null, null, null, null);
    }

    // Update a lending record
    public int updateLending(int id, int bookId, int memberId, String lendingDate, String returnDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_BOOK_ID, bookId);
        values.put(COL_MEMBER_ID, memberId);
        values.put(COL_LENDING_DATE, lendingDate);
        values.put(COL_RETURN_DATE, returnDate);
        return db.update(TABLE_LENDINGS, values, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Delete a lending record
    public int deleteLending(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_LENDINGS, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    // CRUD Operations for Branches Table

    // Insert a new branch
    public long insertBranch(String branchName, String branchAddress) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_BRANCH_NAME, branchName);
        values.put(COL_BRANCH_ADDRESS, branchAddress);
        return db.insert(TABLE_BRANCHES, null, values);
    }

    // Retrieve all branches
    public Cursor getAllBranches() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_BRANCHES, null, null, null, null, null, null);
    }

    // Update a branch
    public int updateBranch(int id, String branchName, String branchAddress) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_BRANCH_NAME, branchName);
        values.put(COL_BRANCH_ADDRESS, branchAddress);
        return db.update(TABLE_BRANCHES, values, COL_BRANCH_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Delete a branch
    public int deleteBranch(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_BRANCHES, COL_BRANCH_ID + "=?", new String[]{String.valueOf(id)});
    }

}
